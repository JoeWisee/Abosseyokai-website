<?php include_once("index.html"); ?>

<?php header( 'Location: /index.html' ) ;  ?>